package tecnm.itch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TutoriasProyectoNickMauroApplicationTests {

	@Test
	void contextLoads() {
	}

}
