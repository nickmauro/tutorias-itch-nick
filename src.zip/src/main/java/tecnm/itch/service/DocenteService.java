package tecnm.itch.service;

import java.util.List;
import java.util.Optional;

import tecnm.itch.model.Docente;

public interface DocenteService {
    Docente buscarDocente(Long id);
    void guardarDocente(Docente docente);
    List<Docente> buscarDocentes();
    void eliminarDocente(Long id);
}