package tecnm.itch.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import tecnm.itch.model.Alumno;
import tecnm.itch.model.Docente;
import tecnm.itch.model.Usuario;
import tecnm.itch.repository.UsuarioRepository;

@Service
public class UsuarioService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public Usuario findByUsername(String username) {
        return usuarioRepository.findByUsername(username);
    }

    public void crearUsuarioParaAlumno(Alumno alumno) {
        Usuario usuario = new Usuario();
        usuario.setUsername(alumno.getMatricula());
        usuario.setPassword(passwordEncoder.encode(alumno.getMatricula()));
        usuario.setRol("ALUMNO");
        usuario.setPersonaId(alumno.getId());
        usuarioRepository.save(usuario);
    }

    public void crearUsuarioParaDocente(Docente docente) {
        Usuario usuario = new Usuario();
        usuario.setUsername(docente.getCorreo());
        usuario.setPassword(passwordEncoder.encode(docente.getRfc()));
        usuario.setRol("DOCENTE");
        usuario.setPersonaId(docente.getId());
        usuarioRepository.save(usuario);
    }
}