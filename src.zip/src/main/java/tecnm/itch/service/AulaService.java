package tecnm.itch.service;

import java.util.List;
import java.util.Optional;

import tecnm.itch.model.Aula;

public interface AulaService {
    Aula buscarAula(Long id);
    void guardarAula(Aula aula);
    List<Aula> buscarAulas();
    void eliminarAula(Long id);
}
