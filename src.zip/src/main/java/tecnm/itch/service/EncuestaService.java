package tecnm.itch.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tecnm.itch.model.Alumno;
import tecnm.itch.model.Encuesta;
import tecnm.itch.repository.EncuestaRepository;

@Service
public class EncuestaService {

    @Autowired
    private EncuestaRepository encuestaRepository;

    public List<Encuesta> findAll() {
        return encuestaRepository.findAll();
    }

    public Encuesta save(Encuesta encuesta) {
        return encuestaRepository.save(encuesta);
    }

    public List<Encuesta> findByAlumno(Long alumnoId) {
        Alumno alumno = new Alumno();
        alumno.setId(alumnoId); // Simulación, ajusta según tu lógica
        return encuestaRepository.findByAlumno(alumno);
    }

    public Encuesta findById(Long id) {
        return encuestaRepository.findById(id).orElse(null);
    }
}