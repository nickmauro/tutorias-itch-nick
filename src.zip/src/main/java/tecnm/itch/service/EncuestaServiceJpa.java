package tecnm.itch.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tecnm.itch.model.Encuesta;
import tecnm.itch.repository.EncuestaRepository;

@Service
public class EncuestaServiceJpa {

    @Autowired
    private EncuestaRepository encuestaRepository;

    public List<Encuesta> findAll() {
        return encuestaRepository.findAll();
    }

    public Encuesta save(Encuesta encuesta) {
        return encuestaRepository.save(encuesta);
    }

    public List<Encuesta> findByAlumnoId(Long alumnoId) {
        // Implementa la lógica para encontrar encuestas por alumno_id
        return encuestaRepository.findAll(); // Placeholder
    }
}