package tecnm.itch.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tecnm.itch.model.Alumno;
import tecnm.itch.model.Canalizacion;
import tecnm.itch.repository.CanalizacionRepository;

@Service
public class CanalizacionService {
    @Autowired
    private CanalizacionRepository canalizacionRepository;

    public List<Canalizacion> findAll() {
        return canalizacionRepository.findAll();
    }

    public List<Canalizacion> findByAlumno(Alumno alumno) {
        return canalizacionRepository.findByAlumno(alumno);
    }

    public Canalizacion save(Canalizacion canalizacion) {
        return canalizacionRepository.save(canalizacion);
    }
}