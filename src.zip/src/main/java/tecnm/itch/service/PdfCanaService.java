package tecnm.itch.service;

import java.io.IOException;
import java.io.OutputStream;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Image;
import com.lowagie.text.Paragraph;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;

import tecnm.itch.model.Alumno;
import tecnm.itch.model.Canalizacion;
import tecnm.itch.model.Docente;
import tecnm.itch.repository.AlumnoRepository;
import tecnm.itch.repository.CanalizacionRepository;
import tecnm.itch.repository.DocenteRepository;

@Service
public class PdfCanaService {

    @Autowired
    private AlumnoRepository alumnoRepository;

    @Autowired
    private DocenteRepository docenteRepository;

    @Autowired
    private CanalizacionRepository canalizacionRepository;

    public void writeCanalizacionPdf(Long canalizacionId, OutputStream out)
            throws IOException, DocumentException {

        Canalizacion canalizacion = canalizacionRepository.findById(canalizacionId)
                .orElseThrow(() -> new IllegalArgumentException("Canalización no encontrada: " + canalizacionId));
        Alumno alumno = canalizacion.getAlumno();
        Docente tutor = canalizacion.getTutor();

        Document document = new Document();
        PdfWriter.getInstance(document, out);
        document.open();

        // 1) Membrete superior
        Image header = Image.getInstance(
                new ClassPathResource("static/images/header.jpg").getURL()
        );
        header.scaleToFit(document.getPageSize().getWidth() - document.leftMargin() - document.rightMargin(), 100);
        header.setAlignment(Image.ALIGN_CENTER);
        document.add(header);

        document.add(new Paragraph(" ")); // Espacio después del membrete

        // 2) Título
        document.add(new Paragraph("Reporte de Canalización", 
                com.lowagie.text.FontFactory.getFont(com.lowagie.text.FontFactory.HELVETICA, 16, com.lowagie.text.Font.BOLD)));
        document.add(new Paragraph(" "));

        // 3) Datos del Alumno Canalizado
        document.add(new Paragraph("Datos del Alumno Canalizado:"));
        document.add(new Paragraph("  • Nombre: " + alumno.getNombre()));
        document.add(new Paragraph("  • Matrícula: " + alumno.getMatricula()));
        document.add(new Paragraph("  • Grupo: " + (alumno.getGrupo() != null ? alumno.getGrupo().getNombre() : "Sin grupo")));
        document.add(new Paragraph(" "));

        // 4) Datos de la Canalización
        document.add(new Paragraph("Detalles de la Canalización:"));
        document.add(new Paragraph("  • Departamento: " + canalizacion.getDepartamento().getNombre()));
        document.add(new Paragraph("  • Causa: " + canalizacion.getCausa()));
        document.add(new Paragraph("  • Fecha: " + canalizacion.getFecha()));
        document.add(new Paragraph("  • Comentarios: " + (canalizacion.getComentarios() != null ? canalizacion.getComentarios() : "Sin comentarios")));
        document.add(new Paragraph(" "));

        // 5) Datos del Tutor
        document.add(new Paragraph("Tutor a Cargo:"));
        document.add(new Paragraph("  • Nombre: " + tutor.getNombre()));
        document.add(new Paragraph("  • Correo: " + tutor.getCorreo()));
        document.add(new Paragraph(" "));

        // 6) Apartado para Sellos del Departamento Académico
        document.add(new Paragraph("Sellos del Departamento Académico:", 
                com.lowagie.text.FontFactory.getFont(com.lowagie.text.FontFactory.HELVETICA, 12, com.lowagie.text.Font.BOLD)));
        PdfPTable selloTable = new PdfPTable(2);
        selloTable.setWidthPercentage(100f);
        selloTable.addCell(new PdfPCell(new Paragraph("Sello del Departamento")));
        selloTable.addCell(new PdfPCell(new Paragraph("Espacio reservado para sello oficial")));
        selloTable.addCell(new PdfPCell(new Paragraph("Fecha de Revisión")));
        selloTable.addCell(new PdfPCell(new Paragraph("_________________________")));
        document.add(selloTable);
        document.add(new Paragraph(" "));

        // 7) Apartado para Reporte - Resultado (llenado a mano)
        document.add(new Paragraph("Reporte - Resultado:", 
                com.lowagie.text.FontFactory.getFont(com.lowagie.text.FontFactory.HELVETICA, 12, com.lowagie.text.Font.BOLD)));
        PdfPTable resultadoTable = new PdfPTable(1);
        resultadoTable.setWidthPercentage(100f);
        PdfPCell resultadoCell = new PdfPCell(new Paragraph("Espacio reservado para reporte del departamento (llenado a mano):"));
        resultadoCell.setMinimumHeight(100f); // Espacio en blanco para escritura manual
        resultadoTable.addCell(resultadoCell);
        document.add(resultadoTable);

        // 8) Membrete inferior
        Image footer = Image.getInstance(
                new ClassPathResource("static/images/footer.jpg").getURL()
        );
        footer.scaleToFit(document.getPageSize().getWidth() - document.leftMargin() - document.rightMargin(), 150);
        footer.setAlignment(Image.ALIGN_CENTER);
        document.add(footer);

        document.close();
    }
}