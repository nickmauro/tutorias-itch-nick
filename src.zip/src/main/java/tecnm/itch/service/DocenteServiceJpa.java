package tecnm.itch.service;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tecnm.itch.model.Docente;
import tecnm.itch.repository.DocenteRepository;

@Service
public class DocenteServiceJpa implements DocenteService {
    
    @Autowired
    private DocenteRepository docenteRepo;

    @Override
    public Docente buscarDocente(Long id) {
        Optional<Docente> optional = docenteRepo.findById(id);
        return optional.isPresent() ? optional.get() : null;
    }

    @Override
    public void guardarDocente(Docente docente) {
        docenteRepo.save(docente);
    }

    @Override
    public List<Docente> buscarDocentes() {
        return docenteRepo.findAll();
    }

    @Override
    public void eliminarDocente(Long id) {
        docenteRepo.deleteById(id);
    }
}
