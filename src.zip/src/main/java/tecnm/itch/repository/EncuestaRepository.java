package tecnm.itch.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import tecnm.itch.model.Alumno;
import tecnm.itch.model.Encuesta;
import tecnm.itch.model.Pregunta;

public interface EncuestaRepository extends JpaRepository<Encuesta, Long> {
    List<Encuesta> findByAlumno(Alumno alumno);
    List<Encuesta> findAll();
    List<Encuesta> findByPregunta(Pregunta pregunta);
    List<Encuesta> findByAlumnoId(Long alumnoId);
}