package tecnm.itch.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import tecnm.itch.model.EvaluacionDocente;

public interface EvaluacionDocenteRepository extends JpaRepository<EvaluacionDocente, Long> {
    List<EvaluacionDocente> findByDocenteId(Long docenteId);

    @Query("SELECT COUNT(DISTINCT e.docente.id) FROM EvaluacionDocente e WHERE e.docente.id = :docenteId")
    Long countDistinctAlumnosByDocenteId(@Param("docenteId") Long docenteId);
}