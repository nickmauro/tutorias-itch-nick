package tecnm.itch.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import tecnm.itch.model.Grupo;

public interface GrupoRepository extends JpaRepository<Grupo, Long> {
    List<Grupo> findByCarreraId(Long carreraId);
    List<Grupo> findByMateriaId(Long materiaId);
    List<Grupo> findByTutorId(Long tutorId);

    // Verificar si un grupo tiene alumnos asignados
    @Query("SELECT COUNT(a) FROM Alumno a WHERE a.grupo.id = :grupoId")
    Long countAlumnosByGrupoId(@Param("grupoId") Long grupoId);
}