package tecnm.itch.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import tecnm.itch.model.PreguntaDocente;

public interface PreguntaDocenteRepository extends JpaRepository<PreguntaDocente, Long> {
}