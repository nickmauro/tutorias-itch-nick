package tecnm.itch.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import tecnm.itch.model.Calificacion;

public interface CalificacionRepository extends JpaRepository<Calificacion, Long> {
    Calificacion findByActividadIdAndAlumnoId(Long actividadId, Long alumnoId);
}