package tecnm.itch.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import tecnm.itch.model.Docente;

public interface DocenteRepository extends JpaRepository<Docente, Long> {
    List<Docente> findByCarreraId(Long carreraId);
    Docente findByCorreo(String correo);
}