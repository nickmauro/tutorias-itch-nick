package tecnm.itch.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import tecnm.itch.model.Usuario;
import tecnm.itch.repository.UsuarioRepository;
import tecnm.itch.security.CustomUserDetails;

@Configuration
public class UserDetailsConfig {

    private static final Logger logger = LoggerFactory.getLogger(UserDetailsConfig.class);

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Bean
    public UserDetailsService userDetailsService() {
        logger.info("Registrando UserDetailsService bean");
        return username -> {
            logger.info("Intentando autenticar usuario con username: {}", username);
            Usuario usuario = usuarioRepository.findByUsername(username);
            if (usuario == null) {
                logger.warn("Usuario no encontrado en la base de datos: {}", username);
                throw new UsernameNotFoundException("Usuario no encontrado: " + username);
            }

            logger.info("Usuario encontrado: username={}, password={}, rol={}", 
                usuario.getUsername(), usuario.getPassword(), usuario.getRol());
            String role = usuario.getRol().toUpperCase();
            return new CustomUserDetails(
                usuario.getUsername(),
                usuario.getPassword(),
                role,
                java.util.Collections.singletonList(new SimpleGrantedAuthority("ROLE_" + role))
            );
        };
    }
}