package tecnm.itch.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;
import tecnm.itch.model.Actividad;
import tecnm.itch.model.ActividadForm;
import tecnm.itch.model.Grupo;
import tecnm.itch.model.Materia;
import tecnm.itch.repository.CarreraRepository;
import tecnm.itch.repository.GrupoRepository;
import tecnm.itch.repository.MateriaRepository;
import tecnm.itch.service.ActividadService;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/admin/actividades")
public class ActividadController {

    @Autowired
    private ActividadService actividadService;

    @Autowired
    private GrupoRepository grupoRepository;

    @Autowired
    private MateriaRepository materiaRepository;

    @Autowired
    private CarreraRepository carreraRepository;

    @GetMapping
    public String listarActividades(Model model) {
        model.addAttribute("actividades", actividadService.buscarActividades());
        model.addAttribute("carreras", carreraRepository.findAll());
        return "actividades/lista";
    }

    @GetMapping("/nueva")
    public String nuevaActividad(Model model) {
        ActividadForm actividadForm = new ActividadForm();
        model.addAttribute("actividadForm", actividadForm);
        model.addAttribute("carreras", carreraRepository.findAll());
        model.addAttribute("materias", materiaRepository.findAll());
        return "actividades/form";
    }

    @PostMapping("/agregar-actividad")
    public String agregarActividad(@ModelAttribute("actividadForm") ActividadForm actividadForm, Model model) {
        actividadForm.agregarActividad();
        model.addAttribute("carreras", carreraRepository.findAll());
        model.addAttribute("materias", materiaRepository.findAll());
        return "actividades/form";
    }

    @PostMapping("/guardar")
    public String guardarActividades(@Valid @ModelAttribute("actividadForm") ActividadForm actividadForm, BindingResult result, Model model) {
        if (result.hasErrors() || actividadForm.getMateriaId() == null) {
            if (actividadForm.getMateriaId() == null) {
                result.rejectValue("materiaId", "error.materiaId", "Debe seleccionar una materia");
            }
            model.addAttribute("materias", materiaRepository.findAll());
            return "actividades/form";
        }

        // Obtener la materia seleccionada
        Materia materia = materiaRepository.findById(actividadForm.getMateriaId())
                .orElseThrow(() -> new IllegalArgumentException("Materia no encontrada"));

        // Verificar si estamos editando una actividad existente
        if (actividadForm.getId() != null) {
            // Modo edición: actualizar la actividad existente
            Actividad actividadExistente = actividadService.buscarActividad(actividadForm.getId());
            if (actividadExistente == null) {
                model.addAttribute("error", "Actividad no encontrada para editar.");
                model.addAttribute("materias", materiaRepository.findAll());
                return "actividades/form";
            }

            // Actualizar los datos de la actividad existente
            Actividad actividadActualizada = actividadForm.getActividades().get(0); // Solo una actividad en modo edición
            actividadExistente.setDescripcion(actividadActualizada.getDescripcion());
            actividadExistente.setFechaEntrega(actividadActualizada.getFechaEntrega());
            actividadExistente.setPuntajeMaximo(actividadActualizada.getPuntajeMaximo());
            actividadExistente.setMateria(materia);
            // Nota: No actualizamos el grupo, ya que se mantiene el mismo

            try {
                actividadService.guardarActividad(actividadExistente); // Guardar la actividad actualizada
            } catch (Exception e) {
                model.addAttribute("error", "Error al actualizar la actividad: " + e.getMessage());
                model.addAttribute("materias", materiaRepository.findAll());
                return "actividades/form";
            }
        } else {
            // Modo creación: crear actividades para todos los grupos de la materia
            List<Grupo> gruposConMateria = grupoRepository.findByMateriaId(actividadForm.getMateriaId());

            if (gruposConMateria.isEmpty()) {
                model.addAttribute("error", "No hay grupos asignados a esta materia.");
                model.addAttribute("materias", materiaRepository.findAll());
                return "actividades/form";
            }

            // Crear una copia de las actividades para cada grupo
            List<Actividad> actividadesAGuardar = new ArrayList<>();
            for (Grupo grupo : gruposConMateria) {
                for (Actividad actividad : actividadForm.getActividades()) {
                    Actividad nuevaActividad = new Actividad();
                    nuevaActividad.setDescripcion(actividad.getDescripcion());
                    nuevaActividad.setFechaEntrega(actividad.getFechaEntrega());
                    nuevaActividad.setPuntajeMaximo(actividad.getPuntajeMaximo());
                    nuevaActividad.setGrupo(grupo);
                    nuevaActividad.setMateria(materia);
                    actividadesAGuardar.add(nuevaActividad);
                }
            }

            // Guardar todas las actividades
            try {
                actividadService.guardarActividades(actividadesAGuardar);
            } catch (Exception e) {
                model.addAttribute("error", "Error al guardar las actividades: " + e.getMessage());
                model.addAttribute("materias", materiaRepository.findAll());
                return "actividades/form";
            }
        }

        return "redirect:/admin/actividades";
    }

    @GetMapping("/editar/{id}")
    public String editarActividad(@PathVariable Long id, Model model) {
        Actividad actividad = actividadService.buscarActividad(id);
        if (actividad == null) {
            throw new IllegalArgumentException("Actividad no encontrada: " + id);
        }

        // Crear un ActividadForm con una sola actividad para la edición
        ActividadForm actividadForm = new ActividadForm();
        actividadForm.setId(id); // Guardamos el ID para saber que es una edición
        actividadForm.getActividades().clear();
        actividadForm.getActividades().add(actividad);
        actividadForm.setMateriaId(actividad.getMateria().getId());

        model.addAttribute("actividadForm", actividadForm);
        model.addAttribute("materias", materiaRepository.findAll());
        return "actividades/form";
    }
    
    @GetMapping("/eliminar/{id}")
    public String eliminarActividad(@PathVariable Long id) {
        actividadService.eliminarActividad(id);
        return "redirect:/admin/actividades";
    }
}