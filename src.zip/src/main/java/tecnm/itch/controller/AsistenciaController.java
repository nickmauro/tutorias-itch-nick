package tecnm.itch.controller;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import tecnm.itch.model.Alumno;
import tecnm.itch.model.Asistencia;
import tecnm.itch.model.Docente;
import tecnm.itch.model.Grupo;
import tecnm.itch.repository.AlumnoRepository;
import tecnm.itch.repository.DocenteRepository;
import tecnm.itch.repository.GrupoRepository;
import tecnm.itch.security.CustomUserDetails;
import tecnm.itch.service.AsistenciaService;

@Controller
@RequestMapping("/docente/asistencias")
public class AsistenciaController {

    @Autowired
    private GrupoRepository grupoRepository;

    @Autowired
    private AlumnoRepository alumnoRepository;

    @Autowired
    private AsistenciaService asistenciaService;

    @Autowired
    private DocenteRepository docenteRepository;

    @GetMapping
    public String inicio(Model model) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
        String username = userDetails.getUsername();

        Docente docente = docenteRepository.findByCorreo(username);
        if (docente == null) {
            throw new RuntimeException("Docente no encontrado para el usuario: " + username);
        }

        List<Grupo> grupos = grupoRepository.findByTutorId(docente.getId());
        if (grupos.isEmpty()) {
            model.addAttribute("mensaje", "No tienes grupos asignados.");
            return "docente/asistencias";
        }

        Long primerGrupoId = grupos.get(0).getId();
        return "redirect:/docente/asistencias/grupo/" + primerGrupoId;
    }

    @GetMapping("/grupo/{id}")
    public String mostrarAsistencia(@PathVariable Long id, Model model) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
        String username = userDetails.getUsername();
        Docente docente = docenteRepository.findByCorreo(username);

        Grupo grupo = grupoRepository.findById(id).orElseThrow(() -> new RuntimeException("Grupo no encontrado: " + id));
        if (!grupo.getTutor().getId().equals(docente.getId())) {
            throw new RuntimeException("No tienes permiso para acceder a este grupo.");
        }

        List<Alumno> alumnos = alumnoRepository.findByGrupoId(id);
        if (alumnos.isEmpty()) {
            model.addAttribute("mensaje", "No hay alumnos asignados a este grupo.");
        }

        String periodo = grupo.getPeriodo();
        LocalDate inicioPeriodo = LocalDate.parse(periodo + "-01", DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        long semanasTranscurridas = ChronoUnit.WEEKS.between(inicioPeriodo, LocalDate.now()) + 1;
        int semanaActual = (int) Math.min(semanasTranscurridas, 16);

        List<Asistencia> asistencias = asistenciaService.findByGrupoIdAndPeriodo(id, periodo);

        // Preparar un mapa de asistencias por alumno y semana
        Map<Long, Map<Integer, Boolean>> asistenciasPorAlumno = new HashMap<>();
        for (Asistencia asistencia : asistencias) {
            Long alumnoId = asistencia.getAlumno().getId();
            int semana = asistencia.getSemana();
            if (!asistenciasPorAlumno.containsKey(alumnoId)) {
                asistenciasPorAlumno.put(alumnoId, new HashMap<>());
            }
            asistenciasPorAlumno.get(alumnoId).put(semana, asistencia.isAsistio());
        }

        model.addAttribute("grupo", grupo);
        model.addAttribute("alumnos", alumnos);
        model.addAttribute("asistenciasPorAlumno", asistenciasPorAlumno);
        model.addAttribute("semanaActual", semanaActual);
        model.addAttribute("periodo", periodo);
        model.addAttribute("docente", docente);
        return "docente/asistencias";
    }

    @PostMapping("/grupo/{id}")
    public String registrarAsistencia(@PathVariable Long id, 
            @RequestParam(required = false) List<String> asistio, 
            Model model) {
        Grupo grupo = grupoRepository.findById(id).orElseThrow(() -> new RuntimeException("Grupo no encontrado: " + id));
        String periodo = grupo.getPeriodo();

        // Obtener todas las asistencias existentes para este grupo y periodo
        List<Asistencia> asistenciasExistentes = asistenciaService.findByGrupoIdAndPeriodo(id, periodo);

        // Crear un mapa para rastrear las asistencias marcadas
        Map<Long, Map<Integer, Boolean>> asistenciasMarcadas = new HashMap<>();
        if (asistio != null) {
            for (String asistioValue : asistio) {
                // El valor viene en el formato "alumnoId-semana", por ejemplo, "1-1"
                String[] partes = asistioValue.split("-");
                if (partes.length != 2) {
                    continue; // Ignorar valores mal formados
                }
                Long alumnoId = Long.valueOf(partes[0]);
                int semana = Integer.parseInt(partes[1]);

                if (!asistenciasMarcadas.containsKey(alumnoId)) {
                    asistenciasMarcadas.put(alumnoId, new HashMap<>());
                }
                asistenciasMarcadas.get(alumnoId).put(semana, true);
            }
        }

        // Procesar todas las combinaciones posibles de alumno y semana (1 a 16)
        List<Alumno> alumnos = alumnoRepository.findByGrupoId(id);
        for (Alumno alumno : alumnos) {
            Long alumnoId = alumno.getId();
            for (int semana = 1; semana <= 16; semana++) {
                // Usar una variable local para hacerla efectivamente final dentro de la lambda
                final int semanaLocal = semana;
                boolean asistioMarcado = asistenciasMarcadas.containsKey(alumnoId) && 
                                         asistenciasMarcadas.get(alumnoId).containsKey(semanaLocal) && 
                                         asistenciasMarcadas.get(alumnoId).get(semanaLocal);

                // Buscar si ya existe una asistencia para este alumno, semana y periodo
                Optional<Asistencia> asistenciaExistente = asistenciasExistentes.stream()
                    .filter(a -> a.getAlumno().getId().equals(alumnoId) && a.getSemana() == semanaLocal)
                    .findFirst();

                if (asistenciaExistente.isPresent()) {
                    // Actualizar asistencia existente
                    Asistencia asistencia = asistenciaExistente.get();
                    if (!asistioMarcado) {
                        // Si se desmarcó, eliminar la asistencia
                        asistenciaService.delete(asistencia);
                    }
                } else if (asistioMarcado) {
                    // Crear nueva asistencia si está marcada y no existe
                    Asistencia nuevaAsistencia = new Asistencia();
                    nuevaAsistencia.setGrupo(grupo);
                    nuevaAsistencia.setAlumno(alumno);
                    nuevaAsistencia.setSemana(semanaLocal);
                    nuevaAsistencia.setPeriodo(periodo);
                    nuevaAsistencia.setAsistio(true);
                    asistenciaService.save(nuevaAsistencia);
                }
            }
        }

        return "redirect:/docente/asistencias/grupo/" + id;
    }
}