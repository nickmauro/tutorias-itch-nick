package tecnm.itch.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import tecnm.itch.model.Actividad;
import tecnm.itch.model.Alumno;
import tecnm.itch.model.Asistencia;
import tecnm.itch.model.Calificacion;
import tecnm.itch.model.Canalizacion;
import tecnm.itch.model.Encuesta;
import tecnm.itch.model.EvaluacionDocente;
import tecnm.itch.model.Grupo;
import tecnm.itch.model.Pregunta;
import tecnm.itch.model.PreguntaDocente;
import tecnm.itch.repository.ActividadRepository;
import tecnm.itch.repository.AlumnoRepository;
import tecnm.itch.repository.AsistenciaRepository;
import tecnm.itch.repository.CanalizacionRepository;
import tecnm.itch.repository.EncuestaRepository;
import tecnm.itch.repository.EvaluacionDocenteRepository;
import tecnm.itch.repository.PreguntaDocenteRepository;
import tecnm.itch.repository.PreguntaRepository;
import tecnm.itch.security.CustomUserDetails;
import tecnm.itch.service.CalificacionService;
import tecnm.itch.service.EvaluacionDocenteService;

@Controller
@RequestMapping("/alumno")
public class Alumno_Controller {

    @Autowired
    private AlumnoRepository alumnoRepository;

    @Autowired
    private ActividadRepository actividadRepository;

    @Autowired
    private CalificacionService calificacionService;

    @Autowired
    private CanalizacionRepository canalizacionRepository;

    @Autowired
    private PreguntaDocenteRepository preguntaDocenteRepository;

    @Autowired
    private EvaluacionDocenteRepository evaluacionDocenteRepository;

    @Autowired
    private EvaluacionDocenteService evaluacionDocenteService;

    @Autowired
    private AsistenciaRepository asistenciaRepository;

    @Autowired
    private PreguntaRepository preguntaRepository;

    @Autowired
    private EncuestaRepository encuestaRepository;

    @GetMapping
    public String redirectToHome() {
        return "redirect:/alumno/home";
    }

    @GetMapping("/home")
    public String home(Model model) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
        String matricula = userDetails.getUsername();

        Alumno alumno = alumnoRepository.findByMatricula(matricula);
        if (alumno == null) {
            model.addAttribute("errorMessage", "Alumno no encontrado.");
            return "alumno/home";
        }

        Grupo grupo = alumno.getGrupo();
        if (grupo == null) {
            model.addAttribute("errorMessage", "No estás asignado a ningún grupo.");
            return "alumno/home";
        }

        model.addAttribute("alumno", alumno);
        model.addAttribute("grupo", grupo);
        model.addAttribute("materia", grupo.getMateria());
        model.addAttribute("hora", grupo.getHora());
        model.addAttribute("dia", grupo.getDia());
        model.addAttribute("compañeros", grupo.getAlumnos().stream().filter(a -> !a.getId().equals(alumno.getId())).collect(Collectors.toList()));
        model.addAttribute("tutor", grupo.getTutor());
        return "alumno/home";
    }

    @GetMapping("/encuesta")
    public String encuesta(Model model) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
        String matricula = userDetails.getUsername();

        Alumno alumno = alumnoRepository.findByMatricula(matricula);
        if (alumno == null) {
            model.addAttribute("errorMessage", "Alumno no encontrado.");
            return "alumno/encuesta";
        }

        // Cargar las preguntas de la tabla pregunta
        List<Pregunta> preguntas = preguntaRepository.findAll();

        // Verificar si el alumno ya respondió la encuesta
        List<Encuesta> encuestasExistentes = encuestaRepository.findByAlumnoId(alumno.getId());
        boolean yaRespondio = !encuestasExistentes.isEmpty();

        model.addAttribute("alumno", alumno);
        model.addAttribute("preguntas", preguntas);
        model.addAttribute("yaRespondio", yaRespondio);
        return "alumno/encuesta";
    }

    @PostMapping("/guardar-encuesta")
    @ResponseBody
    public String guardarEncuesta(@RequestParam Map<String, String> respuestas) {
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
            String matricula = userDetails.getUsername();

            Alumno alumno = alumnoRepository.findByMatricula(matricula);
            if (alumno == null) {
                return "error: Alumno no encontrado.";
            }

            // Verificar si el alumno ya respondió la encuesta
            List<Encuesta> encuestasExistentes = encuestaRepository.findByAlumnoId(alumno.getId());
            if (!encuestasExistentes.isEmpty()) {
                return "error: Ya has respondido la encuesta.";
            }

            // Guardar las respuestas
            for (Map.Entry<String, String> entry : respuestas.entrySet()) {
                String key = entry.getKey();
                if (key.startsWith("respuesta_")) {
                    Long preguntaId = Long.parseLong(key.replace("respuesta_", ""));
                    String respuesta = entry.getValue();

                    Pregunta pregunta = preguntaRepository.findById(preguntaId).orElse(null);
                    if (pregunta == null) {
                        continue; // Saltar si la pregunta no existe
                    }

                    Encuesta encuesta = new Encuesta();
                    encuesta.setAlumno(alumno);
                    encuesta.setPregunta(pregunta);
                    encuesta.setRespuesta(respuesta);
                    encuestaRepository.save(encuesta);
                }
            }

            return "success";
        } catch (Exception e) {
            return "error: " + e.getMessage();
        }
    }

    @GetMapping("/canalizaciones")
    public String canalizaciones(Model model) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
        String matricula = userDetails.getUsername();

        Alumno alumno = alumnoRepository.findByMatricula(matricula);
        if (alumno == null) {
            model.addAttribute("errorMessage", "Alumno no encontrado.");
            return "alumno/canalizaciones";
        }

        List<Canalizacion> canalizaciones = canalizacionRepository.findByAlumnoId(alumno.getId());
        model.addAttribute("canalizaciones", canalizaciones);
        model.addAttribute("alumno", alumno);
        return "alumno/canalizaciones";
    }

    @GetMapping("/actividades")
    public String actividades(Model model) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
        String matricula = userDetails.getUsername();

        Alumno alumno = alumnoRepository.findByMatricula(matricula);
        if (alumno == null) {
            model.addAttribute("errorMessage", "Alumno no encontrado.");
            return "alumno/actividades";
        }

        Grupo grupo = alumno.getGrupo();
        if (grupo == null) {
            model.addAttribute("errorMessage", "No estás asignado a ningún grupo.");
            return "alumno/actividades";
        }

        List<Actividad> actividades = actividadRepository.findByGrupoId(grupo.getId());
        List<Calificacion> calificaciones = calificacionService.buscarCalificaciones().stream()
                .filter(c -> c.getAlumno().getId().equals(alumno.getId()))
                .collect(Collectors.toList());

        Map<Long, Calificacion> calificacionesPorActividad = new HashMap<>();
        for (Calificacion calificacion : calificaciones) {
            calificacionesPorActividad.put(calificacion.getActividad().getId(), calificacion);
        }

        model.addAttribute("alumno", alumno);
        model.addAttribute("actividades", actividades);
        model.addAttribute("calificacionesPorActividad", calificacionesPorActividad);

        return "alumno/actividades";
    }

    @GetMapping("/evaluar-tutor")
    public String evaluarTutor(Model model) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
        String matricula = userDetails.getUsername();

        Alumno alumno = alumnoRepository.findByMatricula(matricula);
        if (alumno == null) {
            model.addAttribute("errorMessage", "Alumno no encontrado.");
            model.addAttribute("yaEvaluado", false);
            return "alumno/evaluar_tutor";
        }

        Grupo grupo = alumno.getGrupo();
        if (grupo == null) {
            model.addAttribute("errorMessage", "No estás asignado a ningún grupo.");
            model.addAttribute("yaEvaluado", false);
            return "alumno/evaluar_tutor";
        }

        List<EvaluacionDocente> evaluacionesExistentes = evaluacionDocenteRepository.findByDocenteId(grupo.getTutor().getId());
        boolean yaEvaluado = evaluacionesExistentes.stream()
                .anyMatch(e -> e.getDocente().getId().equals(grupo.getTutor().getId()) && e.getAlumno() != null && e.getAlumno().getId().equals(alumno.getId()));

        // Cargar las preguntas siempre, incluso si ya evaluó
        List<PreguntaDocente> preguntas;
        try {
            preguntas = preguntaDocenteRepository.findAll();
            if (preguntas.isEmpty()) {
                model.addAttribute("errorMessage", "No hay preguntas disponibles para la evaluación.");
                model.addAttribute("yaEvaluado", false);
                return "alumno/evaluar_tutor";
            }
        } catch (Exception e) {
            model.addAttribute("errorMessage", "Error al cargar las preguntas: " + e.getMessage());
            model.addAttribute("yaEvaluado", false);
            return "alumno/evaluar_tutor";
        }

        model.addAttribute("yaEvaluado", yaEvaluado);
        model.addAttribute("tutor", grupo.getTutor());
        model.addAttribute("alumno", alumno);
        if (!yaEvaluado) {
            model.addAttribute("preguntas", preguntas);
        }

        return "alumno/evaluar_tutor";
    }

    @PostMapping("/guardar-evaluacion-tutor")
    @ResponseBody
    public String guardarEvaluacionTutor(@RequestParam("preguntaIds") List<Long> preguntaIds,
                                         @RequestParam("valoraciones") List<Integer> valoraciones) {
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
            String matricula = userDetails.getUsername();

            Alumno alumno = alumnoRepository.findByMatricula(matricula);
            if (alumno == null) {
                return "error: Alumno no encontrado.";
            }

            Grupo grupo = alumno.getGrupo();
            if (grupo == null) {
                return "error: No estás asignado a ningún grupo.";
            }

            List<EvaluacionDocente> evaluacionesExistentes = evaluacionDocenteRepository.findByDocenteId(grupo.getTutor().getId());
            boolean yaEvaluado = evaluacionesExistentes.stream()
                    .anyMatch(e -> e.getDocente().getId().equals(grupo.getTutor().getId()) && e.getAlumno() != null && e.getAlumno().getId().equals(alumno.getId()));
            if (yaEvaluado) {
                return "error: Ya has evaluado a tu tutor.";
            }

            for (int i = 0; i < preguntaIds.size(); i++) {
                EvaluacionDocente evaluacion = new EvaluacionDocente();
                evaluacion.setDocente(grupo.getTutor());
                evaluacion.setPregunta(preguntaDocenteRepository.findById(preguntaIds.get(i)).orElse(null));
                evaluacion.setValoracion(valoraciones.get(i));
                evaluacion.setAlumno(alumno);
                evaluacionDocenteRepository.save(evaluacion);
            }

            return "success";
        } catch (Exception e) {
            return "error: " + e.getMessage();
        }
    }

    @GetMapping("/asistencias")
    public String asistencias(Model model) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
        String matricula = userDetails.getUsername();

        Alumno alumno = alumnoRepository.findByMatricula(matricula);
        if (alumno == null) {
            model.addAttribute("errorMessage", "Alumno no encontrado.");
            return "alumno/asistencias";
        }

        List<Asistencia> asistencias = asistenciaRepository.findByAlumnoId(alumno.getId());
        model.addAttribute("alumno", alumno);
        model.addAttribute("asistencias", asistencias);
        return "alumno/asistencias";
    }
}