package tecnm.itch.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import jakarta.validation.Valid;
import tecnm.itch.model.Alumno;
import tecnm.itch.model.Grupo;
import tecnm.itch.repository.AlumnoRepository;
import tecnm.itch.repository.GrupoRepository;
import tecnm.itch.service.CarreraService;

@Controller
@RequestMapping("/admin/alumnos")
public class AlumnoController {

    @Autowired
    private AlumnoRepository alumnoRepository;
    
    @Autowired
    private GrupoRepository grupoRepository;
    
    @Autowired
    private CarreraService carreraService;

    @GetMapping
    public String listarAlumnos(Model model) {
        model.addAttribute("alumnos", alumnoRepository.findAll());
        model.addAttribute("grupos", grupoRepository.findAll()); // Corregido: eliminado el duplicado
        return "alumnos/lista";
    }

    @GetMapping("/nuevo")
    public String nuevoAlumno(Model model) {
        model.addAttribute("alumno", new Alumno());
        model.addAttribute("carreras", carreraService.findAll());
        return "alumnos/form";
    }

    @GetMapping("/asignar")
    public String mostrarFormularioAsignar(Model model, @RequestParam(required = false) Long carreraId) {
        model.addAttribute("carreras", carreraService.findAll());
        if (carreraId != null) {
            model.addAttribute("grupos", grupoRepository.findByCarreraId(carreraId));
            model.addAttribute("alumnos", alumnoRepository.findByCarreraId(carreraId));
            model.addAttribute("alumnosAsignados", alumnoRepository.findByCarreraIdAndGrupoIsNotNull(carreraId));
        } else {
            model.addAttribute("grupos", grupoRepository.findAll());
            model.addAttribute("alumnos", alumnoRepository.findAll());
            model.addAttribute("alumnosAsignados", alumnoRepository.findByGrupoIsNotNull());
        }
        return "alumnos/asignarAlumnos";
    }
    
    @PostMapping("/asignar")
    public String asignarAlumno(@RequestParam Long alumnoId, @RequestParam Long grupoId, RedirectAttributes redirectAttributes) {
        try {
            Alumno alumno = alumnoRepository.findById(alumnoId).orElseThrow(() -> new IllegalArgumentException("Alumno no encontrado"));
            Grupo grupo = grupoRepository.findById(grupoId).orElseThrow(() -> new IllegalArgumentException("Grupo no encontrado"));
            alumno.setGrupo(grupo);
            alumnoRepository.save(alumno);
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Error al asignar el alumno al grupo: " + e.getMessage());
        }
        return "redirect:/admin/alumnos";
    }
    
    @PostMapping
    public String guardarAlumno(@Valid Alumno alumno, BindingResult result, Model model, RedirectAttributes redirectAttributes) {
        // Validar si la matrícula ya existe en otro alumno
        Alumno existingAlumno = alumnoRepository.findByMatricula(alumno.getMatricula());
        if (existingAlumno != null && (alumno.getId() == null || !alumno.getId().equals(existingAlumno.getId()))) {
            result.rejectValue("matricula", "error.matricula", "La matrícula ya está registrada para otro alumno.");
        }

        if (result.hasErrors()) {
            model.addAttribute("carreras", carreraService.findAll());
            return "alumnos/form";
        }

        try {
            alumnoRepository.save(alumno);
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Error al guardar el alumno: " + e.getMessage());
            return "redirect:/admin/alumnos";
        }

        return "redirect:/admin/alumnos";
    }

    @GetMapping("/editar/{id}")
    public String editarAlumno(@PathVariable Long id, Model model) {
        model.addAttribute("alumno", alumnoRepository.findById(id).orElse(null));
        model.addAttribute("carreras", carreraService.findAll());
        return "alumnos/form";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminarAlumno(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            alumnoRepository.deleteById(id);
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Error al eliminar el alumno: " + e.getMessage());
        }
        return "redirect:/admin/alumnos";
    }
}