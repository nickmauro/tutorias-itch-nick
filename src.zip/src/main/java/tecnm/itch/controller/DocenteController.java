package tecnm.itch.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import tecnm.itch.model.Docente;
import tecnm.itch.model.Grupo;
import tecnm.itch.repository.DocenteRepository;
import tecnm.itch.repository.GrupoRepository;
import tecnm.itch.service.CarreraService;
import tecnm.itch.service.DocenteService;

@Controller
@RequestMapping("/admin/docentes")
public class DocenteController {

    @Autowired
    private DocenteService docenteService;
    
    @Autowired
    private DocenteRepository docenteRepository;
    
    @Autowired
    private GrupoRepository grupoRepository;

    @Autowired
    private CarreraService carreraService;

    @GetMapping
    public String listarDocentes(Model model) {
        model.addAttribute("docentes", docenteService.buscarDocentes());
        return "docentes/lista";
    }
    
    @GetMapping("/asignar")
    public String mostrarFormularioAsignarDocente(Model model, @RequestParam(required = false) Long carreraId) {
        model.addAttribute("carreras", carreraService.findAll());
        if (carreraId != null) {
            model.addAttribute("docentes", docenteRepository.findByCarreraId(carreraId));
            model.addAttribute("grupos", grupoRepository.findByCarreraId(carreraId));
        } else {
            model.addAttribute("docentes", docenteRepository.findAll());
            model.addAttribute("grupos", grupoRepository.findAll());
        }
        return "docentes/asignarDocentes";
    }

    @PostMapping("/asignar")
    public String asignarDocente(@RequestParam Long docenteId, @RequestParam Long grupoId) {
        Docente docente = docenteRepository.findById(docenteId).orElseThrow();
        Grupo grupo = grupoRepository.findById(grupoId).orElseThrow();
        grupo.setTutor(docente);
        grupoRepository.save(grupo);
        return "redirect:/admin/docentes";
    }

    @GetMapping("/nuevo")
    public String nuevoDocente(Model model) {
        model.addAttribute("docente", new Docente());
        model.addAttribute("carreras", carreraService.findAll());
        return "docentes/form";
    }

    @PostMapping("/guardar")
    public String guardarDocente(Docente docente) {
        docenteService.guardarDocente(docente);
        return "redirect:/admin/docentes";
    }

    @GetMapping("/editar/{id}")
    public String editarDocente(@PathVariable Long id, Model model) {
        Docente docente = docenteService.buscarDocente(id);
        model.addAttribute("docente", docente);
        model.addAttribute("carreras", carreraService.findAll());
        return "docentes/form";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminarDocente(@PathVariable Long id) {
        docenteService.eliminarDocente(id);
        return "redirect:/admin/docentes";
    }
}
