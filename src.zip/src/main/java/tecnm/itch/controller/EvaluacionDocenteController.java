package tecnm.itch.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import tecnm.itch.model.Docente;
import tecnm.itch.model.PreguntaDocente;
import tecnm.itch.repository.DocenteRepository;
import tecnm.itch.service.EvaluacionDocenteService;

@Controller
@RequestMapping("/admin/evaluaciones/docentes")
public class EvaluacionDocenteController {

    @Autowired
    private EvaluacionDocenteService evaluacionDocenteService;

    @Autowired
    private DocenteRepository docenteRepository;

    @GetMapping
    public String listarDocentes(Model model) {
        List<Docente> docentes = docenteRepository.findAll();
        model.addAttribute("docentes", docentes);
        return "evaluaciones_docente/lista";
    }

    @GetMapping("/ver/{docenteId}")
    public String verEvaluacion(@PathVariable Long docenteId, Model model) {
        Docente docente = docenteRepository.findById(docenteId).orElse(null);
        if (docente == null) {
            model.addAttribute("errorMessage", "Docente no encontrado.");
            return "evaluaciones_docente/ver_evaluacion";
        }

        // Obtener todas las preguntas
        List<PreguntaDocente> todasLasPreguntas = evaluacionDocenteService.findAllPreguntas();
        Map<PreguntaDocente, Double> promedios = evaluacionDocenteService.calcularPromediosPorPregunta(docenteId);
        long totalAlumnos = evaluacionDocenteService.countDistinctAlumnosByDocenteId(docenteId);

        // Asegurar que todas las preguntas tengan un porcentaje (0% si no hay datos)
        Map<PreguntaDocente, Double> promediosCompletos = new HashMap<>();
        for (PreguntaDocente pregunta : todasLasPreguntas) {
            promediosCompletos.put(pregunta, promedios.getOrDefault(pregunta, 0.0));
        }

        model.addAttribute("docente", docente);
        model.addAttribute("preguntas", todasLasPreguntas); // Pasar todas las preguntas explícitamente
        model.addAttribute("promedios", promediosCompletos);
        model.addAttribute("totalAlumnos", totalAlumnos);
        return "evaluaciones_docente/ver_evaluacion";
    }
}