package tecnm.itch.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import tecnm.itch.model.Alumno;
import tecnm.itch.model.Encuesta;
import tecnm.itch.model.Pregunta;
import tecnm.itch.repository.AlumnoRepository;
import tecnm.itch.repository.PreguntaRepository;
import tecnm.itch.service.EncuestaService;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/admin/encuestas")
public class EncuestaController {

    @Autowired
    private EncuestaService encuestaService;

    @Autowired
    private AlumnoRepository alumnoRepository;

    @Autowired
    private PreguntaRepository preguntaRepository; // Añadido

    @GetMapping
    public String listarEncuestas(Model model) {
        model.addAttribute("alumnos", alumnoRepository.findAll());
        model.addAttribute("encuestas", encuestaService.findAll());
        return "encuestas/lista";
    }

    @GetMapping("/ver/{alumnoId}")
    public String verRespuestas(@PathVariable Long alumnoId, Model model) {
        Alumno alumno = alumnoRepository.findById(alumnoId).orElse(null);
        if (alumno == null) {
            model.addAttribute("errorMessage", "Alumno no encontrado.");
            return "encuestas/ver_respuestas";
        }

        // Obtener todas las preguntas
        List<Pregunta> todasLasPreguntas = preguntaRepository.findAll();
        List<Encuesta> encuestasExistentes = encuestaService.findByAlumno(alumnoId); // Ajusta según tu implementación

        // Mapear respuestas (o "Sin respuesta" si no existe)
        List<Encuesta> encuestasCompletas = new ArrayList<>();
        for (Pregunta pregunta : todasLasPreguntas) {
            Encuesta encuesta = encuestasExistentes.stream()
                    .filter(e -> e.getPregunta().getId().equals(pregunta.getId()))
                    .findFirst()
                    .orElse(new Encuesta());
            encuesta.setAlumno(alumno);
            encuesta.setPregunta(pregunta);
            if (encuesta.getRespuesta() == null) {
                encuesta.setRespuesta("Sin respuesta");
            }
            encuestasCompletas.add(encuesta);
        }

        model.addAttribute("alumno", alumno);
        model.addAttribute("encuestas", encuestasCompletas);
        return "encuestas/ver_respuestas";
    }
}