package tecnm.itch.controller;


import tecnm.itch.model.Aula;
import tecnm.itch.service.AulaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/admin/aulas")
public class AulaController {

    @Autowired
    private AulaService aulaService;

    @GetMapping
    public String listarAulas(Model model) {
        model.addAttribute("aulas", aulaService.buscarAulas());
        return "aulas/lista";
    }

    @GetMapping("/nuevo")
    public String nuevaAula(Model model) {
        model.addAttribute("aula", new Aula());
        return "aulas/form";
    }

    @PostMapping
    public String guardarAula(Aula aula) {
        aulaService.guardarAula(aula);
        return "redirect:/admin/aulas";
    }

    @GetMapping("/editar/{id}")
    public String editarAula(@PathVariable Long id, Model model) {
        Aula aula = aulaService.buscarAula(id);
        model.addAttribute("aula", aula);
        return "aulas/form";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminarAula(@PathVariable Long id) {
        aulaService.eliminarAula(id);
        return "redirect:/admin/aulas";
    }
}
