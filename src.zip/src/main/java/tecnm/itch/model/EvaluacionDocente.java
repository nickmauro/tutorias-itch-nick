package tecnm.itch.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;

@Entity
public class EvaluacionDocente {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "docente_id", nullable = false)
    private Docente docente;

    @ManyToOne
    @JoinColumn(name = "alumno_id", nullable = false)
    private Alumno alumno; // Nuevo campo para rastrear quién evaluó
    
    @ManyToOne
    @JoinColumn(name = "pregunta_id", nullable = false)
    private PreguntaDocente pregunta;

    @Min(value = 1, message = "La valoración debe ser al menos 1")
    @Max(value = 5, message = "La valoración no puede ser mayor a 5")
    private int valoracion;

    // Getters y Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Docente getDocente() {
        return docente;
    }

    public void setDocente(Docente docente) {
        this.docente = docente;
    }

    public PreguntaDocente getPregunta() {
        return pregunta;
    }

    public void setPregunta(PreguntaDocente pregunta) {
        this.pregunta = pregunta;
    }
    
    public Alumno getAlumno() {
        return alumno;
    }

    public void setAlumno(Alumno alumno) {
        this.alumno = alumno;
    }

    public int getValoracion() {
        return valoracion;
    }

    public void setValoracion(int valoracion) {
        this.valoracion = valoracion;
    }

    @Override
    public String toString() {
        return "EvaluacionDocente [id=" + id + ", docente=" + (docente != null ? docente.getId() : "null") +
               ", pregunta=" + (pregunta != null ? pregunta.getTexto() : "null") +
               ", alumno=" + (alumno != null ? alumno.getId() : "null") +
               ", valoracion=" + valoracion + "]";
    }
}