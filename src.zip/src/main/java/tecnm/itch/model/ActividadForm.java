package tecnm.itch.model;

import java.util.ArrayList;
import java.util.List;

public class ActividadForm {

    private Long id; // Añadimos el ID para identificar si es una edición
    private Long materiaId;
    private List<Actividad> actividades;

    public ActividadForm() {
        this.actividades = new ArrayList<>();
        this.actividades.add(new Actividad());
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getMateriaId() {
        return materiaId;
    }

    public void setMateriaId(Long materiaId) {
        this.materiaId = materiaId;
    }

    public List<Actividad> getActividades() {
        return actividades;
    }

    public void setActividades(List<Actividad> actividades) {
        this.actividades = actividades;
    }

    public void agregarActividad() {
        this.actividades.add(new Actividad());
    }
}