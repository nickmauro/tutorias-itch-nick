package tecnm.itch.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import tecnm.itch.model.Docente;
import tecnm.itch.model.PreguntaDocente;
import tecnm.itch.repository.DocenteRepository;
import tecnm.itch.security.CustomUserDetails;
import tecnm.itch.service.EvaluacionDocenteService;

@Controller
@RequestMapping("/docente/evaluacion")
public class EvaluacionDocenteDocController {

    @Autowired
    private EvaluacionDocenteService evaluacionDocenteService;

    @Autowired
    private DocenteRepository docenteRepository;

    @GetMapping
    public String verEvaluacionDocente(Model model) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
        String username = userDetails.getUsername();

        Docente docente = docenteRepository.findByCorreo(username);
        if (docente == null) {
            model.addAttribute("errorMessage", "Docente no encontrado.");
            return "docente/evaluaciones/ver_evaluacion";
        }

        // Obtener todas las preguntas
        List<PreguntaDocente> todasLasPreguntas = evaluacionDocenteService.findAllPreguntas();
        Map<PreguntaDocente, Double> promedios = evaluacionDocenteService.calcularPromediosPorPregunta(docente.getId());
        long totalAlumnos = evaluacionDocenteService.countDistinctAlumnosByDocenteId(docente.getId());

        // Asegurar que todas las preguntas tengan un porcentaje (0% si no hay datos)
        Map<PreguntaDocente, Double> promediosCompletos = new HashMap<>();
        for (PreguntaDocente pregunta : todasLasPreguntas) {
            promediosCompletos.put(pregunta, promedios.getOrDefault(pregunta, 0.0));
        }

        model.addAttribute("docente", docente);
        model.addAttribute("preguntas", todasLasPreguntas);
        model.addAttribute("promedios", promediosCompletos);
        model.addAttribute("totalAlumnos", totalAlumnos);
        return "docente/evaluaciones/ver_evaluacion";
    }
}