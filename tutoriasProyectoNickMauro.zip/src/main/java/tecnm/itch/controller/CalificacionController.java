package tecnm.itch.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import tecnm.itch.model.Actividad;
import tecnm.itch.model.Calificacion;
import tecnm.itch.repository.ActividadRepository;
import tecnm.itch.repository.AlumnoRepository;
import tecnm.itch.service.CalificacionService;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/admin/calificaciones")
public class CalificacionController {

    @Autowired
    private CalificacionService calificacionService;

    @Autowired
    private ActividadRepository actividadRepository;

    @Autowired
    private AlumnoRepository alumnoRepository;

    @GetMapping
    public String listarCalificaciones(Model model) {
        model.addAttribute("calificaciones", calificacionService.buscarCalificaciones());
        return "calificaciones/lista";
    }

    @GetMapping("/evaluar/{actividadId}")
    public String evaluarActividad(@PathVariable Long actividadId, Model model) {
        Actividad actividad = actividadRepository.findById(actividadId)
                .orElseThrow(() -> new IllegalArgumentException("Actividad no encontrada: " + actividadId));
        List<Calificacion> calificaciones = calificacionService.buscarCalificaciones();

        // Crear un mapa de calificaciones por alumno para facilitar el acceso en la vista
        Map<Long, Integer> calificacionesPorAlumno = new HashMap<>();
        for (Calificacion calificacion : calificaciones) {
            if (calificacion.getActividad().getId().equals(actividadId)) {
                calificacionesPorAlumno.put(calificacion.getAlumno().getId(), calificacion.getCalificacion());
            }
        }

        model.addAttribute("actividad", actividad);
        model.addAttribute("alumnos", actividad.getGrupo().getAlumnos());
        model.addAttribute("calificacionesPorAlumno", calificacionesPorAlumno);
        return "calificaciones/evaluar";
    }

    @PostMapping("/guardar-calificacion")
    @ResponseBody
    public String guardarCalificacion(@RequestParam Long actividadId, @RequestParam Long alumnoId, @RequestParam Integer calificacion) {
        try {
            if (calificacion < 0 || calificacion > 100) {
                return "error: La calificación debe estar entre 0 y 100";
            }
            calificacionService.asignarCalificacion(actividadId, alumnoId, calificacion);
            return "success";
        } catch (Exception e) {
            return "error: " + e.getMessage();
        }
    }
}