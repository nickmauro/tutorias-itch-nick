package tecnm.itch.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import jakarta.validation.Valid;
import tecnm.itch.model.Materia;
import tecnm.itch.repository.MateriaRepository;

@Controller
@RequestMapping("/admin/materias")
public class MateriaController {

    @Autowired
    private MateriaRepository materiaRepository;

    @GetMapping
    public String listarMaterias(Model model) {
        model.addAttribute("materias", materiaRepository.findAll());
        return "materias/lista";
    }

    @GetMapping("/nuevo")
    public String nuevaMateria(Model model) {
        model.addAttribute("materia", new Materia());
        return "materias/form";
    }

    @PostMapping
    public String guardarMateria(@Valid Materia materia, BindingResult result, Model model) {
        if (result.hasErrors()) {
            return "materias/form";
        }
        materiaRepository.save(materia);
        return "redirect:/admin/materias";
    }

    @GetMapping("/editar/{id}")
    public String editarMateria(@PathVariable Long id, Model model) {
        model.addAttribute("materia", materiaRepository.findById(id).orElse(null));
        return "materias/form";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminarMateria(@PathVariable Long id) {
        materiaRepository.deleteById(id);
        return "redirect:/admin/materias";
    }
}