package tecnm.itch.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.lowagie.text.DocumentException;

import jakarta.servlet.http.HttpServletResponse;
import tecnm.itch.model.Docente;
import tecnm.itch.model.Grupo;
import tecnm.itch.repository.DocenteRepository;
import tecnm.itch.repository.GrupoRepository;
import tecnm.itch.security.CustomUserDetails;
import tecnm.itch.service.PdfService;

@Controller
@RequestMapping("/docente")
public class Docente_Controller {

    @Autowired
    private GrupoRepository grupoRepository;

    @Autowired
    private DocenteRepository docenteRepository;

    @Autowired
    private PdfService pdfService;

    @GetMapping
    public String home(Model model) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
        String username = userDetails.getUsername();

        Docente docente = docenteRepository.findByCorreo(username);
        if (docente == null) {
            throw new RuntimeException("Docente no encontrado para el usuario: " + username);
        }

        List<Grupo> grupos = grupoRepository.findByTutorId(docente.getId());
        model.addAttribute("grupos", grupos);
        model.addAttribute("docente", docente);
        return "docente/home";
    }

    @GetMapping("/generarHorarioPDF/{id}")
    public void generarHorarioPDF(@PathVariable Long id, HttpServletResponse resp) 
            throws IOException, DocumentException {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
        String username = userDetails.getUsername();
        Docente docente = docenteRepository.findByCorreo(username);
        
        Grupo grupo = grupoRepository.findById(id).orElseThrow(() -> new RuntimeException("Grupo no encontrado: " + id));
        if (!grupo.getTutor().getId().equals(docente.getId())) {
            throw new RuntimeException("No tienes permiso para acceder a este grupo.");
        }

        resp.setContentType("application/pdf");
        resp.setHeader("Content-Disposition", "inline; filename=horario_" + id + ".pdf");
        pdfService.writeHorarioPdf(id, resp.getOutputStream());
    }
}