package tecnm.itch.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.lowagie.text.DocumentException;

import jakarta.servlet.http.HttpServletResponse;
import tecnm.itch.model.Alumno;
import tecnm.itch.model.Canalizacion;
import tecnm.itch.model.Docente;
import tecnm.itch.model.Encuesta;
import tecnm.itch.model.Grupo;
import tecnm.itch.model.Pregunta;
import tecnm.itch.repository.AlumnoRepository;
import tecnm.itch.repository.DocenteRepository;
import tecnm.itch.repository.GrupoRepository;
import tecnm.itch.repository.PreguntaRepository;
import tecnm.itch.security.CustomUserDetails;
import tecnm.itch.service.CanalizacionService;
import tecnm.itch.service.DepartamentoService;
import tecnm.itch.service.EncuestaService;
import tecnm.itch.service.PdfCanaService;

@Controller
@RequestMapping("/docente/encuestas")
public class EncuestaDocController {

    @Autowired
    private EncuestaService encuestaService;

    @Autowired
    private AlumnoRepository alumnoRepository;

    @Autowired
    private PreguntaRepository preguntaRepository;

    @Autowired
    private DocenteRepository docenteRepository;

    @Autowired
    private GrupoRepository grupoRepository;

    @Autowired
    private DepartamentoService departamentoService;

    @Autowired
    private CanalizacionService canalizacionService;

    @Autowired
    private PdfCanaService pdfCanaService;

    @GetMapping
    public String listarGrupos(Model model) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
        String username = userDetails.getUsername();

        Docente docente = docenteRepository.findByCorreo(username);
        if (docente == null) {
            model.addAttribute("errorMessage", "Docente no encontrado.");
            return "docente/encuestas/lista_grupos";
        }

        List<Grupo> grupos = grupoRepository.findByTutorId(docente.getId());
        if (grupos.isEmpty()) {
            model.addAttribute("errorMessage", "No tienes grupos asignados.");
        }

        model.addAttribute("grupos", grupos);
        model.addAttribute("docente", docente);
        return "docente/encuestas/lista_grupos";
    }

    @GetMapping("/grupo/{grupoId}")
    public String listarAlumnosPorGrupo(@PathVariable Long grupoId, Model model) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
        String username = userDetails.getUsername();
        Docente docente = docenteRepository.findByCorreo(username);

        Grupo grupo = grupoRepository.findById(grupoId).orElse(null);
        if (grupo == null || !grupo.getTutor().getId().equals(docente.getId())) {
            model.addAttribute("errorMessage", "Grupo no encontrado o no tienes permiso para acceder.");
            return "docente/encuestas/lista_alumnos";
        }

        List<Alumno> alumnos = alumnoRepository.findByGrupoId(grupoId);
        if (alumnos.isEmpty()) {
            model.addAttribute("errorMessage", "No hay alumnos en este grupo.");
        }

        model.addAttribute("grupo", grupo);
        model.addAttribute("alumnos", alumnos);
        return "docente/encuestas/lista_alumnos";
    }

    @GetMapping("/ver/{alumnoId}")
    public String verRespuestas(@PathVariable Long alumnoId, Model model) {
        Alumno alumno = alumnoRepository.findById(alumnoId).orElse(null);
        if (alumno == null) {
            model.addAttribute("errorMessage", "Alumno no encontrado.");
            return "docente/encuestas/ver_respuestas";
        }

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
        String username = userDetails.getUsername();
        Docente docente = docenteRepository.findByCorreo(username);

        if (!alumno.getGrupo().getTutor().getId().equals(docente.getId())) {
            model.addAttribute("errorMessage", "No tienes permiso para ver las encuestas de este alumno.");
            return "docente/encuestas/ver_respuestas";
        }

        // Obtener todas las preguntas
        List<Pregunta> todasLasPreguntas = preguntaRepository.findAll();
        List<Encuesta> encuestasExistentes = encuestaService.findByAlumno(alumnoId);

        // Mapear respuestas (o "Sin respuesta" si no existe)
        List<Encuesta> encuestasCompletas = new ArrayList<>();
        for (Pregunta pregunta : todasLasPreguntas) {
            Encuesta encuesta = encuestasExistentes.stream()
                    .filter(e -> e.getPregunta().getId().equals(pregunta.getId()))
                    .findFirst()
                    .orElse(new Encuesta());
            encuesta.setAlumno(alumno);
            encuesta.setPregunta(pregunta);
            if (encuesta.getRespuesta() == null) {
                encuesta.setRespuesta("Sin respuesta");
            }
            encuestasCompletas.add(encuesta);
        }

        // Obtener canalizaciones existentes para este alumno
        List<Canalizacion> canalizaciones = canalizacionService.findByAlumno(alumno);

        model.addAttribute("alumno", alumno);
        model.addAttribute("encuestas", encuestasCompletas);
        model.addAttribute("canalizaciones", canalizaciones);
        return "docente/encuestas/ver_respuestas";
    }

    @GetMapping("/canalizar/{alumnoId}")
    public String mostrarFormularioCanalizacion(@PathVariable Long alumnoId, Model model) {
        Alumno alumno = alumnoRepository.findById(alumnoId).orElse(null);
        if (alumno == null) {
            model.addAttribute("errorMessage", "Alumno no encontrado.");
            return "docente/encuestas/canalizar";
        }

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
        String username = userDetails.getUsername();
        Docente tutor = docenteRepository.findByCorreo(username);
        if (tutor == null) {
            model.addAttribute("errorMessage", "Tutor no encontrado.");
            return "docente/encuestas/canalizar";
        }

        if (!alumno.getGrupo().getTutor().getId().equals(tutor.getId())) {
            model.addAttribute("errorMessage", "No tienes permiso para canalizar a este alumno.");
            return "docente/encuestas/canalizar";
        }

        model.addAttribute("alumno", alumno);
        model.addAttribute("tutor", tutor);
        model.addAttribute("departamentos", departamentoService.findAll());
        model.addAttribute("canalizacion", new Canalizacion());
        return "docente/encuestas/canalizar";
    }

    @PostMapping("/canalizar/{alumnoId}")
    public String guardarCanalizacion(@PathVariable Long alumnoId, 
            @RequestParam Long departamentoId, 
            @RequestParam String causa, 
            @RequestParam(required = false) String comentarios, 
            Model model) {
        Alumno alumno = alumnoRepository.findById(alumnoId).orElse(null);
        if (alumno == null) {
            model.addAttribute("errorMessage", "Alumno no encontrado.");
            return "docente/encuestas/canalizar";
        }

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
        String username = userDetails.getUsername();
        Docente tutor = docenteRepository.findByCorreo(username);
        if (tutor == null) {
            model.addAttribute("errorMessage", "Tutor no encontrado.");
            return "docente/encuestas/canalizar";
        }

        if (!alumno.getGrupo().getTutor().getId().equals(tutor.getId())) {
            model.addAttribute("errorMessage", "No tienes permiso para canalizar a este alumno.");
            return "docente/encuestas/canalizar";
        }

        Canalizacion canalizacion = new Canalizacion();
        canalizacion.setAlumno(alumno);
        canalizacion.setTutor(tutor);
        canalizacion.setDepartamento(departamentoService.findById(departamentoId));
        canalizacion.setCausa(causa);
        canalizacion.setFecha(LocalDate.now());
        canalizacion.setComentarios(comentarios);

        canalizacionService.save(canalizacion);
        return "redirect:/docente/encuestas/ver/" + alumnoId;
    }

    @GetMapping("/imprimirReporte/{canalizacionId}")
    public void imprimirReporte(@PathVariable Long canalizacionId, HttpServletResponse response) 
            throws IOException, DocumentException {
        response.setContentType("application/pdf");
        response.setHeader("Content-Disposition", "inline; filename=reporte_canalizacion_" + canalizacionId + ".pdf");
        pdfCanaService.writeCanalizacionPdf(canalizacionId, response.getOutputStream());
    }
}