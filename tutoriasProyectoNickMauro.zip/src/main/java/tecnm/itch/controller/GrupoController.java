package tecnm.itch.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.lowagie.text.DocumentException;

import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;
import tecnm.itch.model.Grupo;
import tecnm.itch.repository.AlumnoRepository;
import tecnm.itch.repository.AulaRepository;
import tecnm.itch.repository.DocenteRepository;
import tecnm.itch.repository.GrupoRepository;
import tecnm.itch.repository.MateriaRepository;
import tecnm.itch.service.CarreraService;
import tecnm.itch.service.PdfService;

@Controller
@RequestMapping("/admin/grupos")
public class GrupoController {

    @Autowired
    private GrupoRepository grupoRepository;

    @Autowired
    private AulaRepository aulaRepository;

    @Autowired
    private MateriaRepository materiaRepository;

    @Autowired
    private DocenteRepository docenteRepository;

    @Autowired
    private CarreraService carreraService;

    @Autowired
    private AlumnoRepository alumnoRepository;
    
    @Autowired
    private PdfService pdfService;
    
    
    @GetMapping
    public String listarGrupos(Model model) {
        model.addAttribute("grupos", grupoRepository.findAll());
        return "grupos/lista";
    }

    @GetMapping("/nuevo")
    public String nuevoGrupo(Model model) {
        model.addAttribute("grupo", new Grupo());
        model.addAttribute("aulas", aulaRepository.findAll());
        model.addAttribute("materias", materiaRepository.findAll());
        model.addAttribute("docentes", docenteRepository.findAll());
        model.addAttribute("carreras", carreraService.findAll());
        return "grupos/form";
    }

    @PostMapping
    public String guardarGrupo(@Valid Grupo grupo, BindingResult result, Model model) {
        if (result.hasErrors()) {
            model.addAttribute("aulas", aulaRepository.findAll());
            model.addAttribute("materias", materiaRepository.findAll());
            model.addAttribute("docentes", docenteRepository.findAll());
            model.addAttribute("carreras", carreraService.findAll());
            return "grupos/form";
        }
        grupoRepository.save(grupo);
        return "redirect:/admin/grupos";
    }

    @GetMapping("/editar/{id}")
    public String editarGrupo(@PathVariable Long id, Model model) {
        model.addAttribute("grupo", grupoRepository.findById(id).orElse(null));
        model.addAttribute("aulas", aulaRepository.findAll());
        model.addAttribute("materias", materiaRepository.findAll());
        model.addAttribute("docentes", docenteRepository.findAll());
        model.addAttribute("carreras", carreraService.findAll());
        return "grupos/form";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminarGrupo(@PathVariable Long id) {
        grupoRepository.deleteById(id);
        return "redirect:/admin/grupos";
    }

    @GetMapping("/generarHorarioPDF/{id}")
    public void generarHorarioPDF(@PathVariable Long id, HttpServletResponse resp) 
            throws IOException, DocumentException {
        resp.setContentType("application/pdf");
        resp.setHeader("Content-Disposition", "inline; filename=horario_" + id + ".pdf");
        pdfService.writeHorarioPdf(id, resp.getOutputStream());
    }


}