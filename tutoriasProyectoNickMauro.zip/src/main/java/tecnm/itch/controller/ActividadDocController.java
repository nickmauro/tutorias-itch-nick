package tecnm.itch.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import tecnm.itch.model.Actividad;
import tecnm.itch.model.Calificacion;
import tecnm.itch.model.Docente;
import tecnm.itch.model.Grupo;
import tecnm.itch.repository.ActividadRepository;
import tecnm.itch.repository.AlumnoRepository;
import tecnm.itch.repository.DocenteRepository;
import tecnm.itch.repository.GrupoRepository;
import tecnm.itch.security.CustomUserDetails;
import tecnm.itch.service.CalificacionService;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/docente/actividades")
public class ActividadDocController {

    @Autowired
    private ActividadRepository actividadRepository;

    @Autowired
    private AlumnoRepository alumnoRepository;

    @Autowired
    private GrupoRepository grupoRepository;

    @Autowired
    private DocenteRepository docenteRepository;

    @Autowired
    private CalificacionService calificacionService;

    @GetMapping
    public String listarGrupos(Model model) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
        String username = userDetails.getUsername();

        Docente docente = docenteRepository.findByCorreo(username);
        if (docente == null) {
            model.addAttribute("errorMessage", "Docente no encontrado.");
            return "docente/actividades/lista_grupos";
        }

        List<Grupo> grupos = grupoRepository.findByTutorId(docente.getId());
        if (grupos.isEmpty()) {
            model.addAttribute("errorMessage", "No tienes grupos asignados.");
        }

        model.addAttribute("grupos", grupos);
        model.addAttribute("docente", docente);
        return "docente/actividades/lista_grupos";
    }

    @GetMapping("/grupo/{grupoId}")
    public String listarActividadesPorGrupo(@PathVariable Long grupoId, Model model) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
        String username = userDetails.getUsername();
        Docente docente = docenteRepository.findByCorreo(username);

        Grupo grupo = grupoRepository.findById(grupoId).orElse(null);
        if (grupo == null || !grupo.getTutor().getId().equals(docente.getId())) {
            model.addAttribute("errorMessage", "Grupo no encontrado o no tienes permiso para acceder.");
            return "docente/actividades/lista_actividades";
        }

        List<Actividad> actividades = actividadRepository.findByGrupoId(grupoId);
        System.out.println("Actividades encontradas para grupo " + grupoId + ": " + actividades.size());
        actividades.forEach(a -> System.out.println("Actividad ID: " + a.getId() + ", Fecha Entrega: " + a.getFechaEntrega()));
        model.addAttribute("grupo", grupo);
        model.addAttribute("actividades", actividades);
        return "docente/actividades/lista_actividades";
    }

    @GetMapping("/evaluar/{actividadId}")
    public String evaluarActividad(@PathVariable Long actividadId, Model model) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
        String username = userDetails.getUsername();
        Docente docente = docenteRepository.findByCorreo(username);

        Actividad actividad = actividadRepository.findById(actividadId)
                .orElseThrow(() -> new IllegalArgumentException("Actividad no encontrada: " + actividadId));
        if (!actividad.getGrupo().getTutor().getId().equals(docente.getId())) {
            model.addAttribute("errorMessage", "No tienes permiso para evaluar esta actividad.");
            return "docente/actividades/evaluar";
        }

        List<Calificacion> calificaciones = calificacionService.buscarCalificaciones();

        // Crear un mapa de calificaciones por alumno para facilitar el acceso en la vista
        Map<Long, Integer> calificacionesPorAlumno = new HashMap<>();
        for (Calificacion calificacion : calificaciones) {
            if (calificacion.getActividad().getId().equals(actividadId)) {
                calificacionesPorAlumno.put(calificacion.getAlumno().getId(), calificacion.getCalificacion());
            }
        }

        model.addAttribute("actividad", actividad);
        model.addAttribute("alumnos", actividad.getGrupo().getAlumnos());
        model.addAttribute("calificacionesPorAlumno", calificacionesPorAlumno);
        return "docente/actividades/evaluar";
    }

    @PostMapping("/guardar-calificacion")
    @ResponseBody
    public String guardarCalificacion(@RequestParam Long actividadId, @RequestParam Long alumnoId, @RequestParam Integer calificacion) {
    	System.out.println("Intentando guardar calificación - Actividad: " + actividadId + ", Alumno: " + alumnoId + ", Calificación: " + calificacion);
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
            String username = userDetails.getUsername();
            Docente docente = docenteRepository.findByCorreo(username);

            Actividad actividad = actividadRepository.findById(actividadId)
                    .orElseThrow(() -> new IllegalArgumentException("Actividad no encontrada: " + actividadId));
            if (!actividad.getGrupo().getTutor().getId().equals(docente.getId())) {
                return "error: No tienes permiso para calificar esta actividad.";
            }

            if (calificacion < 0 || calificacion > 100) {
                return "error: La calificación debe estar entre 0 y 100";
            }
            calificacionService.asignarCalificacion(actividadId, alumnoId, calificacion);
            return "success";
        } catch (Exception e) {
            return "error: " + e.getMessage();
        }
    }
}