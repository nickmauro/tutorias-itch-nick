package tecnm.itch.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import tecnm.itch.model.Asistencia;

public interface AsistenciaRepository extends JpaRepository<Asistencia, Long> {
    // Obtener todas las asistencias de un grupo y periodo (sin filtrar por semana)
    List<Asistencia> findByGrupoIdAndPeriodo(Long grupoId, String periodo);
    List<Asistencia> findByAlumnoId(Long alumnoId);
    // Contar asistencias de un alumno en un grupo y periodo
    @Query("SELECT COUNT(a) FROM Asistencia a WHERE a.alumno.id = :alumnoId AND a.grupo.id = :grupoId AND a.periodo = :periodo AND a.asistio = true")
    Long countAsistenciasByAlunoIdAndGrupoIdAndPeriodo(@Param("alumnoId") Long alunoId, @Param("grupoId") Long grupoId, @Param("periodo") String periodo);
}