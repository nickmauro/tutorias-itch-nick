package tecnm.itch.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import tecnm.itch.model.Usuario;

public interface UsuarioRepository extends JpaRepository<Usuario, Long> {
    Usuario findByUsername(String username); // Método derivado de Spring Data JPA
}