package tecnm.itch.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import tecnm.itch.model.Pregunta;

public interface PreguntaRepository extends JpaRepository<Pregunta, Long> {
}