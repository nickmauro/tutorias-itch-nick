package tecnm.itch.repository;

import tecnm.itch.model.Alumno;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AlumnoRepository extends JpaRepository<Alumno, Long> {
    List<Alumno> findByCarreraId(Long carreraId);
    @Query("SELECT a FROM Alumno a WHERE a.grupo.id = :grupoId")
    List<Alumno> findByGrupoId(@Param("grupoId") Long grupoId);
    List<Alumno> findByCarreraIdAndGrupoIsNotNull(Long carreraId);
    List<Alumno> findByGrupoIsNotNull();
    Alumno findByMatricula(String matricula); // Este método ya existe y lo usaremos
}