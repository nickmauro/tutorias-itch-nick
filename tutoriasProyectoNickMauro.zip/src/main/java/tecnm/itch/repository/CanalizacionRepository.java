package tecnm.itch.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import tecnm.itch.model.Alumno;
import tecnm.itch.model.Canalizacion;
import java.util.List;

public interface CanalizacionRepository extends JpaRepository<Canalizacion, Long> {
    List<Canalizacion> findByAlumno(Alumno alumno);

    // Añadido: Buscar canalizaciones por ID del alumno
    List<Canalizacion> findByAlumnoId(Long alumnoId);
}