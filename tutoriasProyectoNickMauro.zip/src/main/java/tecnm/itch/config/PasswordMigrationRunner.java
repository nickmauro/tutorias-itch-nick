package tecnm.itch.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import tecnm.itch.model.Usuario;
import tecnm.itch.repository.UsuarioRepository;

import java.util.List;

@Component
public class PasswordMigrationRunner implements CommandLineRunner {

    private static final Logger logger = LoggerFactory.getLogger(PasswordMigrationRunner.class);

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) throws Exception {
        logger.info("Iniciando migración de contraseñas...");

        try {
            List<Usuario> usuarios = usuarioRepository.findAll();
            if (usuarios.isEmpty()) {
                logger.warn("No se encontraron usuarios en la base de datos.");
                return;
            }

            for (Usuario usuario : usuarios) {
                String currentPassword = usuario.getPassword();
                if (currentPassword == null || currentPassword.startsWith("$2a$")) {
                    logger.info("La contraseña del usuario {} ya está encriptada o es nula, omitiendo...", usuario.getUsername());
                    continue;
                }

                logger.info("Encriptando contraseña para el usuario: {}", usuario.getUsername());
                String passwordEncriptada = passwordEncoder.encode(currentPassword);
                usuario.setPassword(passwordEncriptada);
                usuarioRepository.save(usuario);
                logger.info("Contraseña actualizada para el usuario {}: {}", usuario.getUsername(), passwordEncriptada);
            }

            logger.info("Migración de contraseñas completada.");
        } catch (Exception e) {
            logger.error("Error durante la migración de contraseñas: {}", e.getMessage(), e);
            throw e; // Relanzamos la excepción para que se detenga la aplicación y se investigue el problema
        }
    }
}