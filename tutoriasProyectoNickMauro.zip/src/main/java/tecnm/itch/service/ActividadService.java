package tecnm.itch.service;

import java.util.List;
import java.util.Optional;

import tecnm.itch.model.Actividad;

public interface ActividadService {
    Actividad buscarActividad(Long id);
    void guardarActividad(Actividad actividad);
    void guardarActividades(List<Actividad> actividades); // Nuevo método para guardar múltiples actividades
    List<Actividad> buscarActividades();
    void eliminarActividad(Long id);
}