package tecnm.itch.service;

import java.util.List;
import java.util.Optional;

import tecnm.itch.model.Materia;

public interface MateriaService {
    Materia buscarMateria(Long id);
    void guardarMateria(Materia materia);
    List<Materia> buscarMaterias();
    void eliminarMateria(Long id);
}