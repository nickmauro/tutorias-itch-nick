package tecnm.itch.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tecnm.itch.model.Actividad;
import tecnm.itch.model.Alumno;
import tecnm.itch.model.Calificacion;
import tecnm.itch.repository.ActividadRepository;
import tecnm.itch.repository.CalificacionRepository;
import tecnm.itch.repository.AlumnoRepository;

@Service
public class CalificacionServiceJpa implements CalificacionService {

    @Autowired
    private CalificacionRepository calificacionRepo;

    @Autowired
    private ActividadRepository actividadRepo;

    @Autowired
    private AlumnoRepository alumnoRepo;

    @Override
    public Calificacion buscarCalificacion(Long id) {
        Optional<Calificacion> optional = calificacionRepo.findById(id);
        return optional.isPresent() ? optional.get() : null;
    }

    @Override
    public void guardarCalificacion(Calificacion calificacion) {
        calificacionRepo.save(calificacion);
    }

    @Override
    public List<Calificacion> buscarCalificaciones() {
        return calificacionRepo.findAll();
    }

    @Override
    public void eliminarCalificacion(Long id) {
        calificacionRepo.deleteById(id);
    }

    @Override
    public void asignarCalificacion(Long actividadId, Long alumnoId, Integer calificacion) {
        Actividad actividad = actividadRepo.findById(actividadId)
                .orElseThrow(() -> new IllegalArgumentException("Actividad no encontrada: " + actividadId));
        Alumno alumno = alumnoRepo.findById(alumnoId)
                .orElseThrow(() -> new IllegalArgumentException("Alumno no encontrado: " + alumnoId));
        Calificacion calificacionEntity = buscarCalificacionPorActividadYAlumno(actividadId, alumnoId);
        if (calificacionEntity == null) {
            calificacionEntity = new Calificacion();
            calificacionEntity.setActividad(actividad);
            calificacionEntity.setAlumno(alumno);
        }
        calificacionEntity.setCalificacion(calificacion);
        guardarCalificacion(calificacionEntity);
    }

    public Calificacion buscarCalificacionPorActividadYAlumno(Long actividadId, Long alumnoId) {
        return calificacionRepo.findByActividadIdAndAlumnoId(actividadId, alumnoId);
    }
}