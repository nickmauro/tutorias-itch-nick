package tecnm.itch.service;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tecnm.itch.model.Grupo;
import tecnm.itch.repository.GrupoRepository;

@Service
public class GrupoServiceJpa implements GrupoService {
    
    @Autowired
    private GrupoRepository grupoRepo;

    @Override
    public Grupo buscarGrupo(Long id) {
        Optional<Grupo> optional = grupoRepo.findById(id);
        return optional.isPresent() ? optional.get() : null;
    }

    @Override
    public void guardarGrupo(Grupo grupo) {
        grupoRepo.save(grupo);
    }

    @Override
    public List<Grupo> buscarGrupos() {
        return grupoRepo.findAll();
    }

    @Override
    public void eliminarGrupo(Long id) {
        grupoRepo.deleteById(id);
    }
}
