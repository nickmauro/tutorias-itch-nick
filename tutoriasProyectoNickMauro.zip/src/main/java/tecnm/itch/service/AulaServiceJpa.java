package tecnm.itch.service;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tecnm.itch.model.Aula;
import tecnm.itch.repository.AulaRepository;

@Service
public class AulaServiceJpa implements AulaService {
    
    @Autowired
    private AulaRepository aulaRepo;

    @Override
    public Aula buscarAula(Long id) {
        Optional<Aula> optional = aulaRepo.findById(id);
        return optional.isPresent() ? optional.get() : null;
    }

    @Override
    public void guardarAula(Aula aula) {
        aulaRepo.save(aula);
    }

    @Override
    public List<Aula> buscarAulas() {
        return aulaRepo.findAll();
    }

    @Override
    public void eliminarAula(Long id) {
        aulaRepo.deleteById(id);
    }
}
