package tecnm.itch.service;

import java.io.IOException;
import java.io.OutputStream;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Image;
import com.lowagie.text.Paragraph;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;

import tecnm.itch.model.Alumno;
import tecnm.itch.model.Grupo;
import tecnm.itch.repository.AlumnoRepository;
import tecnm.itch.repository.GrupoRepository;

@Service
public class PdfService {

    @Autowired
    private GrupoRepository grupoRepo;
    @Autowired
    private AlumnoRepository alumnoRepo;

    public void writeHorarioPdf(Long grupoId, OutputStream out)
            throws IOException, DocumentException {

        Grupo g = grupoRepo.findById(grupoId)
            .orElseThrow(() -> new IllegalArgumentException("Grupo no encontrado: " + grupoId));

        Document document = new Document();
        PdfWriter.getInstance(document, out);
        document.open();

        // 1) Membrete superior
        Image header = Image.getInstance(
            new ClassPathResource("static/images/header.jpg").getURL()
        );
        header.scaleToFit(document.getPageSize().getWidth() - document.leftMargin() - document.rightMargin(), 100);
        header.setAlignment(Image.ALIGN_CENTER);
        document.add(header);

        document.add(new Paragraph(" ")); // pequeño espacio después del membrete

        // 2) Datos del Grupo
        document.add(new Paragraph("Datos del Grupo:"));
        document.add(new Paragraph("  • ID:       " + g.getId()));
        document.add(new Paragraph("  • Nombre:  " + g.getNombre()));
        document.add(new Paragraph("  • Carrera: " + g.getCarrera().getNombre()));
        document.add(new Paragraph("  • Materia: " + g.getMateria().getNombre()));
        document.add(new Paragraph("  • Aula:    " + g.getAula().getUbicacion())); // Cambiado aquí
        document.add(new Paragraph("  • Día:     " + g.getDia() + "   Hora: " + g.getHora()));
        document.add(new Paragraph("  • Período: " + g.getPeriodo()));
        document.add(new Paragraph(" "));

        // 3) Datos del Tutor
        document.add(new Paragraph("Tutor Asignado:"));
        document.add(new Paragraph("  • Nombre: " + g.getTutor().getNombre()));
        document.add(new Paragraph("  • Correo: " + g.getTutor().getCorreo()));
        document.add(new Paragraph(" "));

        // 4) Tabla de Alumnos
        document.add(new Paragraph("Alumnos Matriculados:"));
        document.add(new Paragraph(" ")); // espacio antes del pie
        PdfPTable table = new PdfPTable(4);
        table.setWidthPercentage(100f);
        table.setWidths(new float[]{1f, 2f, 4f, 3f});
        table.addCell(new PdfPCell(new Paragraph("ID")));
        table.addCell(new PdfPCell(new Paragraph("Matrícula")));
        table.addCell(new PdfPCell(new Paragraph("Nombre")));
        table.addCell(new PdfPCell(new Paragraph("Carrera")));
        List<Alumno> alumnos = alumnoRepo.findByGrupoId(grupoId);
        for (Alumno a : alumnos) {
            table.addCell(a.getId().toString());
            table.addCell(a.getMatricula());
            table.addCell(a.getNombre());
            table.addCell(a.getCarrera().getNombre());
        }
        document.add(table);

        document.add(new Paragraph(" ")); // espacio antes del pie

        // 5) Membrete inferior
        Image footer = Image.getInstance(
            new ClassPathResource("static/images/footer.jpg").getURL()
        );
        footer.scaleToFit(document.getPageSize().getWidth() - document.leftMargin() - document.rightMargin(), 150);
        footer.setAlignment(Image.ALIGN_CENTER);
        document.add(footer);

        document.close();
    }
}