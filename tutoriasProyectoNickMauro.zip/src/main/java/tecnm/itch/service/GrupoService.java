package tecnm.itch.service;


import java.util.List;
import java.util.Optional;

import tecnm.itch.model.Grupo;

public interface GrupoService {
    Grupo buscarGrupo(Long id);
    void guardarGrupo(Grupo grupo);
    List<Grupo> buscarGrupos();
    void eliminarGrupo(Long id);
}