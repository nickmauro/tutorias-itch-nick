package tecnm.itch.service;

import java.util.List;
import tecnm.itch.model.Asistencia;

public interface AsistenciaService {

    /**
     * Obtiene todas las asistencias de un grupo y periodo dado.
     */
    List<Asistencia> findByGrupoIdAndPeriodo(Long grupoId, String periodo);

    /**
     * Guarda o actualiza una asistencia
     */
    Asistencia save(Asistencia asistencia);

    /**
     * Elimina una asistencia
     */
    void delete(Asistencia asistencia);
}
