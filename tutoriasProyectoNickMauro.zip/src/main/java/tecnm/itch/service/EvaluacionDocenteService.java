package tecnm.itch.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tecnm.itch.model.EvaluacionDocente;
import tecnm.itch.model.PreguntaDocente;
import tecnm.itch.repository.EvaluacionDocenteRepository;
import tecnm.itch.repository.PreguntaDocenteRepository;

@Service
public class EvaluacionDocenteService {

    @Autowired
    private EvaluacionDocenteRepository evaluacionDocenteRepository;

    @Autowired
    private PreguntaDocenteRepository preguntaDocenteRepository;

    public List<EvaluacionDocente> findByDocenteId(Long docenteId) {
        return evaluacionDocenteRepository.findByDocenteId(docenteId);
    }

    public List<PreguntaDocente> findAllPreguntas() {
        return preguntaDocenteRepository.findAll();
    }

    public Map<PreguntaDocente, Double> calcularPromediosPorPregunta(Long docenteId) {
        List<EvaluacionDocente> evaluaciones = evaluacionDocenteRepository.findByDocenteId(docenteId);
        Map<PreguntaDocente, Double> promedios = new HashMap<>();

        List<PreguntaDocente> preguntas = preguntaDocenteRepository.findAll();
        for (PreguntaDocente pregunta : preguntas) {
            double promedio = evaluaciones.stream()
                    .filter(e -> e.getPregunta().getId().equals(pregunta.getId()))
                    .mapToInt(EvaluacionDocente::getValoracion)
                    .average()
                    .orElse(0.0);
            promedios.put(pregunta, (promedio / 5.0) * 100); // Convertir a porcentaje
        }
        return promedios;
    }

    public long countDistinctAlumnosByDocenteId(Long docenteId) {
        return evaluacionDocenteRepository.countDistinctAlumnosByDocenteId(docenteId);
    }
}