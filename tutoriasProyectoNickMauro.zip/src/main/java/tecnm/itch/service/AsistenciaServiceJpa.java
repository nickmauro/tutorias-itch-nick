package tecnm.itch.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tecnm.itch.model.Asistencia;
import tecnm.itch.repository.AsistenciaRepository;

@Service
public class AsistenciaServiceJpa implements AsistenciaService {

    @Autowired
    private AsistenciaRepository repo;

    @Override
    public List<Asistencia> findByGrupoIdAndPeriodo(Long grupoId, String periodo) {
        return repo.findByGrupoIdAndPeriodo(grupoId, periodo);
    }

    @Override
    public Asistencia save(Asistencia asistencia) {
        return repo.save(asistencia);
    }

    @Override
    public void delete(Asistencia asistencia) {
        repo.delete(asistencia);
    }
}
