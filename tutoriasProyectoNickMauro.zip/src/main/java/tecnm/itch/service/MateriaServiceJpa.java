package tecnm.itch.service;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tecnm.itch.model.Materia;
import tecnm.itch.repository.MateriaRepository;

@Service
public class MateriaServiceJpa implements MateriaService {
    
    @Autowired
    private MateriaRepository materiaRepo;

    @Override
    public Materia buscarMateria(Long id) {
        Optional<Materia> optional = materiaRepo.findById(id);
        return optional.isPresent() ? optional.get() : null;
    }

    @Override
    public void guardarMateria(Materia materia) {
        materiaRepo.save(materia);
    }

    @Override
    public List<Materia> buscarMaterias() {
        return materiaRepo.findAll();
    }

    @Override
    public void eliminarMateria(Long id) {
        materiaRepo.deleteById(id);
    }
}
