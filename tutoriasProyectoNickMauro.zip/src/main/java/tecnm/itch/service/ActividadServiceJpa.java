package tecnm.itch.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tecnm.itch.model.Actividad;
import tecnm.itch.repository.ActividadRepository;

@Service
public class ActividadServiceJpa implements ActividadService {

    @Autowired
    private ActividadRepository actividadRepo;

    @Override
    public Actividad buscarActividad(Long id) {
        Optional<Actividad> optional = actividadRepo.findById(id);
        return optional.isPresent() ? optional.get() : null;
    }

    @Override
    public void guardarActividad(Actividad actividad) {
        actividadRepo.save(actividad);
    }

    @Override
    public void guardarActividades(List<Actividad> actividades) {
        actividadRepo.saveAll(actividades);
    }

    @Override
    public List<Actividad> buscarActividades() {
        return actividadRepo.findAll();
    }

    @Override
    public void eliminarActividad(Long id) {
        actividadRepo.deleteById(id);
    }
}