package tecnm.itch.service;

import java.util.List;
import java.util.Optional;

import tecnm.itch.model.Calificacion;

public interface CalificacionService {
    Calificacion buscarCalificacion(Long id);
    void guardarCalificacion(Calificacion calificacion);
    List<Calificacion> buscarCalificaciones();
    void eliminarCalificacion(Long id);
    void asignarCalificacion(Long actividadId, Long alumnoId, Integer calificacion);
    Calificacion buscarCalificacionPorActividadYAlumno(Long actividadId, Long alumnoId);
}