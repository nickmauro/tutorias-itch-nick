package tecnm.itch.service;

import tecnm.itch.model.Carrera;
import tecnm.itch.repository.CarreraRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jakarta.annotation.PostConstruct;

@Service
public class CarreraService {

    @Autowired
    private CarreraRepository carreraRepository;

    @PostConstruct
    public void inicializarCarreras() {
        if (carreraRepository.count() == 0) {
            Carrera c1 = new Carrera();
            c1.setNombre("ING. Sistemas Computacionales");
            Carrera c2 = new Carrera();
            c2.setNombre("ING. Informática");
            Carrera c3 = new Carrera();
            c3.setNombre("ING. Gestión Empresarial");
            Carrera c4 = new Carrera();
            c4.setNombre("LIC. Contabilidad");
            Carrera c5 = new Carrera();
            c5.setNombre("ING. Civil");
            carreraRepository.save(c1);
            carreraRepository.save(c2);
            carreraRepository.save(c3);
            carreraRepository.save(c4);
            carreraRepository.save(c5);
        }
    }

    // Otros métodos del servicio si los necesitas
    public Iterable<Carrera> findAll() {
        return carreraRepository.findAll();
    }
}