package tecnm.itch;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class PasswordTest {
    public static void main(String[] args) {
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        System.out.println(encoder.matches("21520473", "$2a$10$zfPtwlV48zhTAK3tsZvr3OcIkD9apicNgtgK9tEifKuU9mhSHekeS"));
        System.out.println(encoder.matches("admin123", "$2a$10$aIi.tEd4ZmCM4k7y3A.QKuKyt.G69z0pS05UkIHPCyspWZDreGaCy"));
        System.out.println(encoder.matches("1234567890", "$2a$10$HbGkY5jZNydV6tHjxuyo3eDEay2/VQFQ//raUBmcdNiOiZx8VaMNS"));
    }
}